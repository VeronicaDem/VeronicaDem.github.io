var _0x46a6 = ['Share\x20this\x20on:', 'Facebook', 'open', 'https://www.facebook.com/sharer/sharer.php?u=http%3A//themeforest.net', '_blank', 'Twitter', 'http://twitter.com/share?text=Welcome%20To%20Yui&url=http://themeforest.net&hashtags=template,mobile', 'Mail', 'mailto:someone@example.com?Subject=Hello', 'Cancel', '.share-actions', 'shareActions', 'close', 'notification', '<i\x20class=\x22icon\x20ion-ios-notifications\x22></i>', 'Yui\x20Template', 'Click\x20(x)\x20button\x20to\x20close\x20me', '.open-notification', 'toggle', 'get', '.toggle-theme', 'change', 'body', 'theme-dark', 'toggleTheme', 'color-theme-pink', '[name=\x22radio-color-theme\x22]', '[name=\x22radio-color-theme\x22]:checked', 'toggleClass', '.page[data-name=\x22single\x22]', 'hideStatus', 'page:beforeout', 'detail', 'url', '/single/', '/single-2/', 'selector', 'showStatus', '.page[data-name=\x22author\x22]', '.page[data-name=\x22contact\x22]', '.view', 'tab:show', 'srcElement', 'view-discover', 'hideStatusFast', 'tab:hide', '#app', 'index.html', 'pages/single.html', 'pages/single-2.html', 'pages/single-elements.html', '/author/', 'pages/author.html', '/cards/', 'pages/cards.html', '/cards-author-comments/', '/cards-category/', 'pages/cards-category.html', '/cards-chip/', 'pages/cards-chip.html', 'pages/cards-footer.html', '/cards-medium/', 'pages/cards-medium.html', '/cards-columns/', 'pages/cards-columns.html', '/list-category/', 'pages/list-category.html', '/list-category-author/', 'pages/list-category-author.html', '/list-category-date/', '/slider-1/', 'pages/slider-1.html', '/slider-2/', 'pages/slider-2.html', '/slider-3/', 'pages/slider-3.html', '/slider-4/', 'pages/slider-4.html', 'pages/categories-cards.html', '/categories-columns/', 'pages/categories-columns.html', '/category/', 'pages/category.html', '/author-list/', 'pages/author-list.html', '/contact/', 'pages/contact.html', '/pull-to-refresh/', 'pages/pull-to-refresh.html', '/infinite-scroll/', 'pages/infinite-scroll.html', '/promo-banner/', 'pages/promo-banner.html', 'views', 'create', '.view-main', '#view-categories', '#view-discover', '#view-search', '#view-pages', 'touchstart', 'addClass', 'card-scale', '.card', 'touchend', 'removeClass', '.swiper-slide\x20a', 'click', 'current', 'router', 'navigate', 'attr', 'pageInit', 'searchbar', '.list', '.item-title', '.search-results', 'hide', '.search-preloader', '.page-search\x20.popular-tags\x20li', 'find', 'span', 'text', '.page-search\x20.trending-search\x20ul\x20li', 'search', '.item-title\x20a', 'target', 'closest', '#discover-swiper', 'assign', '#discover-swiper2', 'page:init', '#single-swiper', '.page[data-name=\x22single-2\x22]', '#single-swiper-2', 'ptr:refresh', '<span\x20class=\x22title-date\x22>Tuesday\x2019\x20March</span>', '<h1>Just\x20Now</h1>', '</div>', '<a\x20href=\x22/single/\x22>', '<div\x20class=\x22card\x22>', '<h2\x20class=\x22card-title\x22>How\x20to\x20Get\x20Your\x20First\x20Tattoo\x20Right</h2>', '<div\x20class=\x22card-bottom\x22>', '<div\x20class=\x22card-author\x22>', '<img\x20class=\x22card-author-image\x22\x20src=\x22img/authors/author-1.jpg\x22\x20alt=\x22\x22>', '<div>Camille\x20Aline</div>', '<div\x20class=\x22card-comments\x22><i\x20class=\x22icon\x20ion-ios-text\x22></i>3</div>', '</a>', '.ptr-content', 'prepend', 'ptr', '.infinite-scroll-content', 'infinite', '<li>', '<div\x20class=\x22item-media\x22><img\x20src=\x22img/thumb-15.jpg\x22\x20width=\x2244\x22/></div>', '<div\x20class=\x22item-inner\x22>', '</li>', '<div\x20class=\x22item-content\x22>', '<div\x20class=\x22item-media\x22><img\x20src=\x22img/thumb-16.jpg\x22\x20width=\x2244\x22/></div>', '<div\x20class=\x22item-subtitle\x22>Fashion</div>', '<div\x20class=\x22item-title\x22>Most\x20Beautiful\x20Beach\x20of\x20the\x20Costa\x20Brava</div>', '<div\x20class=\x22item-subtitle\x20bottom-subtitle\x22><img\x20src=\x22img/authors/author-2.jpg\x22>Zorka\x20Ivka</div>', '#infinite-content', 'append', 'infiniteScroll', 'destroy', '.infinite-scroll-preloader', 'remove', '#pages-swiper2', '.page[data-name=\x22slider-3\x22]', '#pages-swiper3', '.page[data-name=\x22slider-4\x22]', '.page[data-name=\x22pull-to-refresh\x22]', '#pages-ptr', '<div\x20class=\x22item-media\x22><img\x20src=\x22img/thumb-25.jpg\x22\x20width=\x2244\x22/></div>', '<div\x20class=\x22item-subtitle\x20bottom-subtitle\x22><i\x20class=\x22icon\x20ion-md-time\x22></i>2\x20hours\x20ago</div>', '#pages-ptr-list', 'done', '.page[data-name=\x22infinite-scroll\x22]', '#pages-infinite-scroll', '<div\x20class=\x22item-media\x22><img\x20src=\x22img/thumb-26.jpg\x22\x20width=\x2244\x22/></div>', '<div\x20class=\x22item-title\x22>The\x20Best\x20Diet\x20for\x20a\x20Flatter\x20Belly</div>', '#pages-infinite-scroll-list', '#pages-infinite-scroll\x20.infinite-scroll-preloader', 'actions'];
(function(_0x465755, _0x4cbf31) {
    var _0xd2c679 = function(_0x48e5e0) {
        while (--_0x48e5e0) {
            _0x465755['push'](_0x465755['shift']());
        }
    };
    _0xd2c679(++_0x4cbf31);
}(_0x46a6, 0x1a0));
var _0x48bd = function(_0x1ee060, _0x37a69a) {
    _0x1ee060 = _0x1ee060 - 0x0;
    var _0x3ea8c9 = _0x46a6[_0x1ee060];
    return _0x3ea8c9;
};
'use strict';
var $$ = Dom7;
var app = new Framework7({
    'root': _0x48bd('0x0'),
    'theme': 'ios',
    'tapHold': !![],
    'view': {
        'stackPages': !![]
    },
    'routes': [{
        'path': '/',
        'url': _0x48bd('0x1')
    }, {
        'path': '/single/',
        'url': _0x48bd('0x2')
    }, {
        'path': '/single-2/',
        'url': _0x48bd('0x3')
    }, {
        'path': '/single-elements/',
        'url': _0x48bd('0x4')
    }, {
        'path': _0x48bd('0x5'),
        'url': _0x48bd('0x6')
    }, {
        'path': _0x48bd('0x7'),
        'url': _0x48bd('0x8')
    }, {
        'path': _0x48bd('0x9'),
        'url': 'pages/cards-author-comments.html'
    }, {
        'path': _0x48bd('0xa'),
        'url': _0x48bd('0xb')
    }, {
        'path': _0x48bd('0xc'),
        'url': _0x48bd('0xd')
    }, {
        'path': '/cards-footer/',
        'url': _0x48bd('0xe')
    }, {
        'path': _0x48bd('0xf'),
        'url': _0x48bd('0x10')
    }, {
        'path': _0x48bd('0x11'),
        'url': _0x48bd('0x12')
    }, {
        'path': _0x48bd('0x13'),
        'url': _0x48bd('0x14')
    }, {
        'path': _0x48bd('0x15'),
        'url': _0x48bd('0x16')
    }, {
        'path': _0x48bd('0x17'),
        'url': 'pages/list-category-date.html'
    }, {
        'path': _0x48bd('0x18'),
        'url': _0x48bd('0x19')
    }, {
        'path': _0x48bd('0x1a'),
        'url': _0x48bd('0x1b')
    }, {
        'path': _0x48bd('0x1c'),
        'url': _0x48bd('0x1d')
    }, {
        'path': _0x48bd('0x1e'),
        'url': _0x48bd('0x1f')
    }, {
        'path': '/categories-cards/',
        'url': _0x48bd('0x20')
    }, {
        'path': _0x48bd('0x21'),
        'url': _0x48bd('0x22')
    }, {
        'path': _0x48bd('0x23'),
        'url': _0x48bd('0x24')
    }, {
        'path': _0x48bd('0x25'),
        'url': _0x48bd('0x26')
    }, {
        'path': _0x48bd('0x27'),
        'url': _0x48bd('0x28')
    }, {
        'path': _0x48bd('0x29'),
        'url': _0x48bd('0x2a')
    }, {
        'path': _0x48bd('0x2b'),
        'url': _0x48bd('0x2c')
    }, {
        'path': _0x48bd('0x2d'),
        'url': _0x48bd('0x2e')
    }]
});
var mainView = app[_0x48bd('0x2f')][_0x48bd('0x30')](_0x48bd('0x31'));
var categoriesView = app[_0x48bd('0x2f')][_0x48bd('0x30')](_0x48bd('0x32'));
var discoverView = app[_0x48bd('0x2f')][_0x48bd('0x30')](_0x48bd('0x33'));
var searchView = app['views'][_0x48bd('0x30')](_0x48bd('0x34'));
var pagesView = app['views'][_0x48bd('0x30')](_0x48bd('0x35'));

function activeCardTouch() {
    $$('.card')['on'](_0x48bd('0x36'), function(_0x5b31ab) {
        $$(this)[_0x48bd('0x37')](_0x48bd('0x38'));
    });
    $$(_0x48bd('0x39'))['on'](_0x48bd('0x3a'), function(_0x5d33ae) {
        $$(this)[_0x48bd('0x3b')](_0x48bd('0x38'));
    });
    $$(_0x48bd('0x39'))['on']('mousedown', function() {
        $$(this)['addClass'](_0x48bd('0x38'));
    });
    $$(_0x48bd('0x39'))['on']('mouseup', function() {
        $$(this)[_0x48bd('0x3b')](_0x48bd('0x38'));
    });
    $$(_0x48bd('0x3c'))['on'](_0x48bd('0x3d'), function(_0x3f4745) {
        app[_0x48bd('0x2f')][_0x48bd('0x3e')][_0x48bd('0x3f')][_0x48bd('0x40')]($$(this)[_0x48bd('0x41')]('data-href'));
    });
}
activeCardTouch();
app['on'](_0x48bd('0x42'), function(_0x10d767) {
    activeCardTouch();
});
var searchbar = app[_0x48bd('0x43')][_0x48bd('0x30')]({
    'el': '.searchbar',
    'searchContainer': _0x48bd('0x44'),
    'searchIn': _0x48bd('0x45'),
    'customSearch': !![],
    'on': {
        'search' (_0x30b965, _0x5a67e9) {
            if (_0x5a67e9 == '') {
                $$(_0x48bd('0x46'))[_0x48bd('0x47')]();
            } else {
                $$(_0x48bd('0x48'))['show']();
                setTimeout(function() {
                    $$('.search-preloader')[_0x48bd('0x47')]();
                    $$(_0x48bd('0x46'))['show']();
                }, 0x1f4);
            }
        },
        'clear' (_0x2e5857, _0x1791ff) {
            $$(_0x48bd('0x46'))[_0x48bd('0x47')]();
        },
        'disable' (_0x256a8) {
            $$('.search-results')[_0x48bd('0x47')]();
        }
    }
});
$$(_0x48bd('0x49'))['on']('click', function(_0x28bcdd) {
    searchbar['search']($$(this)[_0x48bd('0x4a')](_0x48bd('0x4b'))[_0x48bd('0x4c')]());
});
$$(_0x48bd('0x4d'))['on'](_0x48bd('0x3d'), function(_0x655536) {
    searchbar[_0x48bd('0x4e')]($$(this)[_0x48bd('0x4a')](_0x48bd('0x4f'))[_0x48bd('0x4c')]());
});
var swiperOptions = {
    'spaceBetween': 0xa,
    'touchMoveStopPropagation': ![],
    'on': {
        'touchStart': function(_0x277f95) {
            $$(_0x277f95[_0x48bd('0x50')][_0x48bd('0x51')]('.card'))[_0x48bd('0x37')](_0x48bd('0x38'));
        },
        'touchEnd': function(_0x58cacf) {
            $$(_0x58cacf[_0x48bd('0x50')]['closest'](_0x48bd('0x39')))[_0x48bd('0x3b')](_0x48bd('0x38'));
        }
    }
};
var discoverSwiper = new Swiper(_0x48bd('0x52'), Object[_0x48bd('0x53')]({}, swiperOptions, {
    'width': 0x140
}));
var discoverSwiper2 = new Swiper(_0x48bd('0x54'), Object[_0x48bd('0x53')]({}, swiperOptions, {
    'width': 0x104
}));
var discoverSwiper3 = new Swiper('#discover-swiper3', Object[_0x48bd('0x53')]({}, swiperOptions, {
    'width': 0x168
}));
$$(document)['on'](_0x48bd('0x55'), '.page[data-name=\x22single\x22]', function(_0xede795) {
    var _0x5ef681 = new Swiper(_0x48bd('0x56'), Object[_0x48bd('0x53')]({}, swiperOptions, {
        'width': 0x118
    }));
});
$$(document)['on'](_0x48bd('0x55'), _0x48bd('0x57'), function(_0x1d7cda) {
    var _0x510f93 = new Swiper(_0x48bd('0x58'), Object['assign']({}, swiperOptions, {
        'width': 0x118
    }));
});
$$('.ptr-content')['on'](_0x48bd('0x59'), function(_0x25fd3c) {
    setTimeout(function() {
        var _0x48008b = '<div\x20class=\x22title-container\x22>' + _0x48bd('0x5a') + _0x48bd('0x5b') + _0x48bd('0x5c') + _0x48bd('0x5d') + _0x48bd('0x5e') + '<img\x20class=\x22card-image\x22\x20src=\x22img/thumb-14.jpg\x22\x20alt=\x22\x22>' + '<div\x20class=\x22card-infos\x22>' + _0x48bd('0x5f') + _0x48bd('0x60') + _0x48bd('0x61') + _0x48bd('0x62') + _0x48bd('0x63') + _0x48bd('0x5c') + _0x48bd('0x64') + '</div>' + _0x48bd('0x5c') + _0x48bd('0x5c') + _0x48bd('0x65');
        $$(_0x48bd('0x66'))[_0x48bd('0x4a')]('#today-content')[_0x48bd('0x67')](_0x48008b);
        activeCardTouch();
        app[_0x48bd('0x68')]['done']();
    }, 0x3e8);
});
var allowInfinite = !![];
$$(_0x48bd('0x69'))['on'](_0x48bd('0x6a'), function() {
    if (!allowInfinite) return;
    allowInfinite = ![];
    setTimeout(function() {
        allowInfinite = !![];
        var _0x2cec87 = _0x48bd('0x6b') + '<a\x20href=\x22/single/\x22>' + '<div\x20class=\x22item-content\x22>' + _0x48bd('0x6c') + _0x48bd('0x6d') + '<div\x20class=\x22item-subtitle\x22>Fashion</div>' + '<div\x20class=\x22item-title\x22>Archery\x20at\x20the\x202024\x20Olympic\x20Games</div>' + '<div\x20class=\x22item-subtitle\x20bottom-subtitle\x22><img\x20src=\x22img/authors/author-3.jpg\x22>Jess\x20Roxana</div>' + '</div>' + _0x48bd('0x5c') + _0x48bd('0x65') + _0x48bd('0x6e') + _0x48bd('0x6b') + _0x48bd('0x5d') + _0x48bd('0x6f') + _0x48bd('0x70') + '<div\x20class=\x22item-inner\x22>' + _0x48bd('0x71') + _0x48bd('0x72') + _0x48bd('0x73') + _0x48bd('0x5c') + _0x48bd('0x5c') + _0x48bd('0x65') + _0x48bd('0x6e');
        $$(_0x48bd('0x74'))[_0x48bd('0x75')](_0x2cec87);
        app[_0x48bd('0x76')][_0x48bd('0x77')]('.infinite-scroll-content');
        $$(_0x48bd('0x78'))[_0x48bd('0x79')]();
    }, 0x3e8);
});
$$(document)['on'](_0x48bd('0x55'), '.page[data-name=\x22slider-1\x22]', function(_0x47a769) {
    var _0x2f3c0a = new Swiper('#pages-swiper', Object[_0x48bd('0x53')]({}, swiperOptions, {
        'width': 0x140
    }));
});
$$(document)['on']('page:init', '.page[data-name=\x22slider-2\x22]', function(_0x4e2853) {
    var _0x470415 = new Swiper(_0x48bd('0x7a'), Object['assign']({}, swiperOptions, {
        'width': 0x104
    }));
});
$$(document)['on'](_0x48bd('0x55'), _0x48bd('0x7b'), function(_0x1a7936) {
    var _0x1b649f = new Swiper(_0x48bd('0x7c'), Object[_0x48bd('0x53')]({}, swiperOptions, {
        'width': 0x168
    }));
});
$$(document)['on'](_0x48bd('0x55'), _0x48bd('0x7d'), function(_0x207eed) {
    var _0x4065f7 = new Swiper('#pages-swiper4', Object[_0x48bd('0x53')]({}, swiperOptions, {
        'width': 0x118
    }));
});
$$(document)['on'](_0x48bd('0x55'), _0x48bd('0x7e'), function(_0x175106) {
    $$(_0x48bd('0x7f'))['on'](_0x48bd('0x59'), function(_0x175106) {
        setTimeout(function() {
            var _0x1bff79 = _0x48bd('0x6b') + '<a\x20href=\x22/single/\x22>' + _0x48bd('0x6f') + _0x48bd('0x80') + _0x48bd('0x6d') + '<div\x20class=\x22item-subtitle\x22>Fashion</div>' + '<div\x20class=\x22item-title\x22>The\x20Best\x20Diet\x20for\x20a\x20Flatter\x20Belly</div>' + _0x48bd('0x81') + _0x48bd('0x5c') + _0x48bd('0x5c') + '</a>' + _0x48bd('0x6e');
            $$('#pages-ptr')['find'](_0x48bd('0x82'))[_0x48bd('0x67')](_0x1bff79);
            app[_0x48bd('0x68')][_0x48bd('0x83')]($$(_0x48bd('0x7f')));
        }, 0x3e8);
    });
});
$$(document)['on'](_0x48bd('0x55'), _0x48bd('0x84'), function(_0x1af19a) {
    var _0x37812e = !![];
    $$(_0x48bd('0x85'))['on'](_0x48bd('0x6a'), function() {
        if (!_0x37812e) return;
        _0x37812e = ![];
        setTimeout(function() {
            _0x37812e = !![];
            var _0x2fc8a8 = _0x48bd('0x6b') + _0x48bd('0x5d') + _0x48bd('0x6f') + _0x48bd('0x86') + _0x48bd('0x6d') + _0x48bd('0x71') + _0x48bd('0x87') + _0x48bd('0x81') + _0x48bd('0x5c') + _0x48bd('0x5c') + _0x48bd('0x65') + _0x48bd('0x6e');
            $$(_0x48bd('0x88'))[_0x48bd('0x75')](_0x2fc8a8);
            app[_0x48bd('0x76')][_0x48bd('0x77')](_0x48bd('0x85'));
            $$(_0x48bd('0x89'))['remove']();
        }, 0x320);
    });
});
var shareActions = app[_0x48bd('0x8a')][_0x48bd('0x30')]({
    'buttons': [
        [{
            'text': _0x48bd('0x8b'),
            'label': !![]
        }, {
            'text': _0x48bd('0x8c'),
            'bold': !![],
            'onClick': function() {
                window[_0x48bd('0x8d')](_0x48bd('0x8e'), _0x48bd('0x8f'));
            }
        }, {
            'text': _0x48bd('0x90'),
            'bold': !![],
            'onClick': function() {
                window[_0x48bd('0x8d')](_0x48bd('0x91'), _0x48bd('0x8f'));
            }
        }, {
            'text': _0x48bd('0x92'),
            'bold': !![],
            'onClick': function() {
                window[_0x48bd('0x8d')](_0x48bd('0x93'), _0x48bd('0x8f'));
            }
        }],
        [{
            'text': _0x48bd('0x94'),
            'color': 'red'
        }]
    ]
});
$$(_0x48bd('0x95'))['on'](_0x48bd('0x3d'), function() {
    shareActions['open']();
    parent[_0x48bd('0x96')]();
});
shareActions['on'](_0x48bd('0x97'), function() {
    parent[_0x48bd('0x96')]();
});
var myNotification = app[_0x48bd('0x98')]['create']({
    'icon': _0x48bd('0x99'),
    'title': _0x48bd('0x9a'),
    'subtitle': 'This\x20is\x20a\x20mobile\x20notification',
    'text': _0x48bd('0x9b'),
    'closeButton': !![]
});
$$(_0x48bd('0x9c'))['on'](_0x48bd('0x3d'), function() {
    myNotification[_0x48bd('0x8d')]();
});
var toggleTheme = app[_0x48bd('0x9d')][_0x48bd('0x9e')](_0x48bd('0x9f'));
toggleTheme['on'](_0x48bd('0xa0'), function() {
    $$(_0x48bd('0xa1'))['toggleClass'](_0x48bd('0xa2'));
    parent[_0x48bd('0xa3')]();
});
var currentTheme = _0x48bd('0xa4');
$$(_0x48bd('0xa5'))['on'](_0x48bd('0xa0'), function(_0x51fcc6) {
    var _0x30d6d4 = $$(_0x48bd('0xa6'))[_0x48bd('0x41')]('id');
    $$('body')[_0x48bd('0xa7')](currentTheme + '\x20' + _0x30d6d4);
    currentTheme = _0x30d6d4;
});
$$(document)['on'](_0x48bd('0x55'), _0x48bd('0xa8'), function(_0x3c1659, _0x4e8288) {
    parent[_0x48bd('0xa9')]();
});
$$(document)['on'](_0x48bd('0xaa'), _0x48bd('0xa8'), function(_0x4b5f9d, _0xfaafb5) {
    var _0x1ffb89 = _0x4b5f9d[_0x48bd('0xab')][_0x48bd('0x3f')][_0x48bd('0xac')];
    if (_0x1ffb89 != _0x48bd('0xad') && _0x1ffb89 != _0x48bd('0xae') && _0x1ffb89 != _0x48bd('0x5') && _0x1ffb89 != _0x48bd('0x27') && app['views'][_0x48bd('0x3e')]['selector'] != _0x48bd('0x33')) {
        parent['showStatus']();
    }
});
$$(document)['on'](_0x48bd('0x55'), _0x48bd('0x57'), function(_0x2738e7, _0x4aa115) {
    parent[_0x48bd('0xa9')]();
});
$$(document)['on'](_0x48bd('0xaa'), _0x48bd('0x57'), function(_0x35a005, _0x37ad99) {
    var _0x3aa1b1 = _0x35a005[_0x48bd('0xab')][_0x48bd('0x3f')][_0x48bd('0xac')];
    if (_0x3aa1b1 != _0x48bd('0xad') && _0x3aa1b1 != _0x48bd('0xae') && _0x3aa1b1 != _0x48bd('0x5') && _0x3aa1b1 != _0x48bd('0x27') && app[_0x48bd('0x2f')][_0x48bd('0x3e')][_0x48bd('0xaf')] != _0x48bd('0x33')) {
        parent[_0x48bd('0xb0')]();
    }
});
$$(document)['on'](_0x48bd('0x55'), _0x48bd('0xb1'), function(_0x4fff8b, _0x37a567) {
    parent[_0x48bd('0xa9')]();
});
$$(document)['on']('page:beforeout', _0x48bd('0xb1'), function(_0x5092e8, _0x2ad787) {
    var _0x43e15b = _0x5092e8['detail'][_0x48bd('0x3f')][_0x48bd('0xac')];
    if (_0x43e15b != _0x48bd('0xad') && _0x43e15b != _0x48bd('0xae') && _0x43e15b != _0x48bd('0x5') && _0x43e15b != _0x48bd('0x27') && app[_0x48bd('0x2f')][_0x48bd('0x3e')]['selector'] != _0x48bd('0x33')) {
        parent[_0x48bd('0xb0')]();
    }
});
$$(document)['on'](_0x48bd('0x55'), _0x48bd('0xb2'), function(_0x1dcbf3, _0x2f668e) {
    parent[_0x48bd('0xa9')]();
});
$$(document)['on'](_0x48bd('0xaa'), _0x48bd('0xb2'), function(_0x209184, _0x2596d6) {
    var _0x4d6440 = _0x209184[_0x48bd('0xab')]['router']['url'];
    if (_0x4d6440 != _0x48bd('0xad') && _0x4d6440 != _0x48bd('0xae') && _0x4d6440 != _0x48bd('0x5') && _0x4d6440 != _0x48bd('0x27') && app['views'][_0x48bd('0x3e')]['selector'] != _0x48bd('0x33')) {
        parent[_0x48bd('0xb0')]();
    }
});
$$(_0x48bd('0xb3'))['on'](_0x48bd('0xb4'), function(_0x15271e) {
    var _0x426de7 = _0x15271e[_0x48bd('0xb5')]['id'];
    if (_0x426de7 == _0x48bd('0xb6')) {
        parent[_0x48bd('0xb7')]();
    } else {
        var _0x31d83f = app[_0x48bd('0x2f')][_0x48bd('0x3e')]['router'][_0x48bd('0xac')];
        if (_0x31d83f == _0x48bd('0xad') || _0x31d83f == '/single-2') {
            parent[_0x48bd('0xb7')]();
        } else {
            parent['showStatusFast']();
        }
    }
});
$$(_0x48bd('0xb3'))['on'](_0x48bd('0xb8'), function(_0x8dfda5) {
    var _0x28f58b = _0x8dfda5[_0x48bd('0xb5')]['id'];
    if (_0x28f58b == 'view-discover') {
        parent['showStatusFast']();
    } else {
        parent[_0x48bd('0xb7')]();
    }
});